#!/bin/bash

#autorun_variable
form_date=`date +"%d%m%y"`;
fileName='paths.txt'
prefix=${form_date}

#variables
script_path=$(pwd);
dataPaths='dataPaths.txt'

#Variables for path
full_path=$(realpath $0)
dir_path=$(dirname $full_path)



#Read parameters that enter the script when they are entered
# example: $ ./run.sh -f {args1} -p {args2} 
while getopts f:p: flag
do
    case "${flag}" in
        f) fileName=${OPTARG};; # {args1} => -f examplePath.txt
        p) prefix=${OPTARG};; # {args1} => -p myPrefix
    esac
done

#Functions
#====================
KernelVerification ()
{
    #variables
    currentKernel=`uname -r`;
    scriptKernel='5.15.0-52-generic'
    #Test if the kernel matches
    [[ "$currentKernel" == "$scriptKernel" ]] && echo -e " The script runs on the same kernel!" || echo -e " The script does not run on the same kernel!"

}

ShowLoadedData ()
{
        #Display the entered data to see what the user has entered
        echo -e "PathToDirectories : $fileName"
        echo -e "Prefix : $prefix"
}

TestIfPathFileExist ()
{
if [ -f "$script_path/$fileName" ]; #Display the entered data to see what the user has entered
    then
        echo -e "[SUCCESS]The file exists! [${script_path}/${fileName}]"
        #Verification to delete blank lines and vreate new file without blanks line 
        awk 'NF' $fileName > $dataPaths 
    else
        echo -e "[FAIL] The file doesn't exist! [${script_path}/${fileName}]"
        echo -e "Check with FileManager to make sure you have entered the correct name. Or create a new file!"
        exit 1
    fi    
}

Renamer()
{
#Testing if lines not null and save to array
echo -e "\nOperations: "
echo -e "------------------------------------------------------"

renamed=0
line=`head $script_path/$dataPaths`;
while read line;
do
    if [ -d "$dir_path/$line" ];
    then        
        targetPath="$dir_path$line"
        if [ "$(ls -A $targetPath)" ]; 
        then
            echo -e "DIR: [${line}] obsahuje: "
            echo -e "================================================="
            cd -- "$targetPath" &&
            for f in * ; do
            mv -- "$f" "${prefix}_${f}" & ((renamed+=1))
            echo -e "FILE: ${f}  IS RENAMED TO => ${prefix}_${f}"
            done
        fi

        echo -e "\n"
    else
        echo -e "DIR: [${line}] neexistuje!"
    fi
done < $script_path/$fileName    
}

SumcheckRenamedFiles ()
{
echo -e "\nPocet prejmenovanych souboru: $renamed" #bugged fix if [-prázdné složky]
}

#Main code
#============
KernelVerification
ShowLoadedData
TestIfPathFileExist
Renamer
SumcheckRenamedFiles
