#!/bin/bash

#Font Colors
Reset='\033[0m'
BgGreen='\033[42m'
BgRed='\033[41m'
BgYellow='\033[43m'
BgBlue='\033[44m'
bold=$(tput bold)

#variables
script_path=$(pwd);
dataPaths='dataPaths.txt'

#Variables for path
full_path=$(realpath $0)
dir_path=$(dirname $full_path)



#Read parameters that enter the script when they are entered
# example: $ ./run.sh -f {args1} -p {args2} 
while getopts f:p: flag
do
    case "${flag}" in
        f) fileName=${OPTARG};; # {args1} => -f examplePath.txt
        p) prefix=${OPTARG};; # {args1} => -p myPrefix
    esac
done

#Functions
#====================
KernelVerification ()
{
    #variables
    currentKernel=`uname -r`;
    scriptKernel='5.15.0-52-generic'
    #Test if the kernel matches
    [[ "$currentKernel" == "$scriptKernel" ]] && echo -e "${BgGreen} The script runs on the same kernel!"${Reset} || echo -e "${BgRed} The script does not run on the same kernel!${Reset}"

}

InteracticeInput ()
{
        echo -e "\nInteractive data input"
        echo -e "${bold}------------------------${Reset}"
            echo -e "${bold}${BgYellow}<ENTER DATA>${Reset} File with paths: "
            read -r fileName
            
            if [[ -z "$fileName" ]]; #Testing if the user entered it correctly If not, enter it again for $filename.
            then 
                echo -e "The entry cannot be blank!"
                echo -e "${bold}${BgYellow}<ENTER DATA>${Reset} File with paths: "
                read -r fileName
                if [[ -z "$fileName" ]]; #If he doesn't make it a second time. When it starts again.
                then
                    echo -e "Entered data is still blank!  Run it again. \n ${bold}Learn to read what I ask you!${Reset}"
                    exit 1
                fi
            fi 
  
            echo -e "${bold}${BgYellow}<ENTER DATA>${Reset}Prefix: "
            read -r prefix
            if [[ -z "$prefix" ]]; #Testing if the user entered it correctly If not, enter it again for $prefix.
            then
                echo -e "The entry cannot be blank!"
                echo -e "${bold}${BgYellow}<ENTER DATA>${Reset}Prefix: "
                read -r prefix
                if [[ -z "$prefix" ]];  #If he doesn't make it a second time. When it starts again.
                then
                    echo -e "Entered data is still blank! Run it again. \n ${bold}Learn to read what I ask you!${Reset}"
                    exit 1
                fi
            fi
        echo -e "\n"
}

ShowLoadedData ()
{
        #Display the entered data to see what the user has entered
        echo -e "${bold}${BgBlue}PathToDirectories${Reset} : $fileName"
        echo -e "${bold}${BgBlue}Prefix${Reset} : $prefix"
}

TestIfPathFileExist ()
{
if [ -f "$script_path/$fileName" ]; #Display the entered data to see what the user has entered
    then
        echo -e "${bold}${BgGreen}[SUCCESS]${Reset} ${bold}The file exists!${Reset} [${script_path}/${fileName}]"
        #Verification to delete blank lines and vreate new file without blanks line 
        awk 'NF' $fileName > $dataPaths 
    else
        echo -e "${bold}${BgRed}[FAIL]${Reset} ${bold}The file doesn't exist!${Reset} [${script_path}/${fileName}]"
        echo -e "Check with FileManager to make sure you have entered the correct name. Or create a new file!"
        exit 1
    fi    
}

Renamer()
{
#Testing if lines not null and save to array
echo -e "${bold}\nOperations: ${Reset}"
echo -e "${bold}------------------------------------------------------${Reset}"

renamed=0
line=`head $script_path/$dataPaths`;
while read line;
do
    if [ -d "$dir_path/$line" ];
    then        
        targetPath="$dir_path$line"
        if [ "$(ls -A $targetPath)" ]; 
        then
            echo -e "${BgGreen}DIR:${Reset} [${line}] ${bold}obsahuje${Reset}: "
            echo -e "================================================="
            cd -- "$targetPath" &&
            for f in * ; do
            mv -- "$f" "${prefix}_${f}" & ((renamed+=1))
            echo -e "${BgBlue}FILE:${Reset} ${bold}${f}${Reset}  IS RENAMED TO => ${bold}${prefix}_${f}${Reset}"
            done
        fi

        echo -e "\n"
    else
        echo -e "${BgRed}DIR:${Reset} [${line}] ${bold}neexistuje${Reset}!"
    fi
done < $script_path/$fileName    
}

SumcheckRenamedFiles ()
{
echo -e "\nPocet prejmenovanych souboru: $renamed" #bugged fix if [-prázdné složky]
}

#Main code
#============
KernelVerification
if [ -z ${filename} ] & [ -z ${prefix} ]; #Testing if I haven't entered input parameters => I'll enter interactively.
    then
            InteracticeInput
            ShowLoadedData
            TestIfPathFileExist
            Renamer
            SumcheckRenamedFiles

            #expected_status='1'
            #echo -e "Chcete pokračovat?"
            #echo -e "[ANO] = 0 ; [NE] = 1"
            #echo -e "===================="
            #read -r actual_status
    else 
        echo -e "${bold}${BgGreen}[SUCCESS]${Reset} Data through parameters has been successfully loaded!" #Data has been successfully retrieved
        ShowLoadedData
        TestIfPathFileExist
        Renamer
        SumcheckRenamedFiles
fi
