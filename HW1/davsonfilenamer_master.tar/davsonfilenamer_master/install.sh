#!/bin/bash
echo "Installer for Homework#1 :"
echo "------------------------------------"
echo "Installing prerequisites"
sudo apt-get install tree
echo "#Adding an account"
sudo useradd -m -U renamer
echo "#Set up password [default-password: code12569]"
sudo passwd renamer 
echo "#Copying file s to the home folder for user RENAMER: [DIR]davsonfilerenamer"
cp -r /home/renamer/Downloads/davsonfilenamer_master/davsonfilerenamer/ /home/renamer/davsonfilerenamer/
echo "#Setting permissions for files:"
chmod -R 770 /home/renamer/davsonfilerenamer & echo "[#] Permission for folders(Subfolders) '/davsonfilerenamer' [OK]" || echo "[#] Permission for folder 'davsonfilerenamer' [FAIL]"
chmod +x /home/renamer/davsonfilerenamer/autorun.sh & echo "[#] Permission for script '/davsonfilerenamer/autorun.sh' [OK]" || echo "Permission for script '/davsonfilerenamer/autorun.sh' [FAIL]"
chmod +x /home/renamer/davsonfilerenamer/run.sh & echo "[#] Permission for script '/davsonfilerenamer/run.sh' [OK]" || echo "Permission for script '/davsonfilerenamer/run.sh' [FAIL]"
echo "#Copying service"
sudo cp -v /home/renamer/davsonfilerenamer/service/davsonfilerenamer.service /etc/systemd/system
echo "#Copying timer"
sudo cp -v /home/renamer/davsonfilerenamer/timer/davsonfilerenamer.timer /etc/systemd/system
echo "#Installing service"
sudo systemctl deamon-reload
sudo systemctl enable davsonfilerenamer.service
sudo systemctl enable davsonfilerenamer.timer
sudo systemctl start davsonfilerenamer.service
sudo systemctl start davsonfilerenamer.timer

echo "#Prepare workingfolder"
function createFolders ()
{
	mkdir /home/renamer/davsonfilerenamer/BackupRenamerFolder
	mkdir /home/renamer/davsonfilerenamer/BackupRenamerFolder/images/ || echo -e "[DIR]: $script_path/BackupRenamerFolder/images/ [FAIL]"
	mkdir /home/renamer/davsonfilerenamer/BackupRenamerFolder/video/ || echo -e "[DIR]: $script_path/BackupRenamerFolder/video/ [FAIL]"
	mkdir /home/renamer/davsonfilerenamer/BackupRenamerFolder/temps/ || echo -e "[DIR]: $script_path/BackupRenamerFolder/ [FAIL]"
	mkdir /home/renamer/davsonfilerenamer/BackupRenamerFolder/config/ || echo -e "[DIR]: $script_path/BackupRenamerFolder/ [FAIL]"
}

function createFiles ()
{
	touch /home/renamer/davsonfilerenamer/BackupRenamerFolder/images/childs.jpeg || echo -e "[FILE]: /BackupRenamerFolder/images/childs.jpeg [FAIL]"
	touch /home/renamer/davsonfilerenamer/BackupRenamerFolder/images/cat.jpeg || echo -e "[FILE]: /BackupRenamerFolder/images/cat.jpeg [FAIL]"
	touch /home/renamer/davsonfilerenamer/BackupRenamerFolder/images/dog.jpeg || echo -e "[FILE]: /BackupRenamerFolder/images/images/dog.jpeg [FAIL]"
	touch /home/renamer/davsonfilerenamer/BackupRenamerFolder/images/factory.jpeg || echo -e "[FILE]: /BackupRenamerFolder/images/factory.jpeg [FAIL]"
	touch /home/renamer/davsonfilerenamer/BackupRenamerFolder/video/introduce.mp4 || echo -e "[FILE]: /BackupRenamerFolder/video/introduce.mp4 [FAIL]"
	touch /home/renamer/davsonfilerenamer/BackupRenamerFolder/video/video640x320.3gp || echo -e "[FILE]: /BackupRenamerFolder/video/video640x320.3gp [FAIL]"
	touch /home/renamer/davsonfilerenamer/BackupRenamerFolder/temps/var.temp || echo -e "[FILE]: /BackupRenamerFolder/temps/var.temp [FAIL]"
	touch /home/renamer/davsonfilerenamer/BackupRenamerFolder/config/init.conf || echo -e "[FILE]: /BackupRenamerFolder/config/init.conf [FAIL]"
}

function deleteAll ()
{
	rm -r /home/renamer/davsonfilerenamer/BackupRenamerFolder/ || echo -e "[DIR]: Deleted all files from /BackupRenamerFolder/* [FAIL]"
}

if [ -d "/home/renamer/davsonfilerenamer/BackupRenamerFolder/" ];
then
	deleteAll
	createFolders
	createFiles
			
else
	createFolders
	createFiles
fi
echo -e "Defaul folder has been restored!"
tree /home/renamer/davsonfilerenamer/BackupRenamerFolder/
