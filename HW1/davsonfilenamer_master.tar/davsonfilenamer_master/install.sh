#!/bin/bash
user=${whoami}

echo "Installer for Homework#1 :"
echo "------------------------------------"
echo "Installing prerequisites"
sudo apt-get install tree
echo "#Copying file s to the home folder for user RENAMER: [DIR]davsonfilerenamer"
cp -r /home/${user}/Downloads/davsonfilenamer_master/davsonfilerenamer/ /home/${user}/davsonfilerenamer/
echo "#Setting permissions for files:"
chmod -R 770 /home/${user}/davsonfilerenamer & echo "[#] Permission for folders(Subfolders) '/davsonfilerenamer' [OK]" || echo "[#] Permission for folder 'davsonfilerenamer' [FAIL]"
chmod +x /home/${user}/davsonfilerenamer/autorun.sh & echo "[#] Permission for script '/davsonfilerenamer/autorun.sh' [OK]" || echo "Permission for script '/davsonfilerenamer/autorun.sh' [FAIL]"
chmod +x /home/${user}/davsonfilerenamer/run.sh & echo "[#] Permission for script '/davsonfilerenamer/run.sh' [OK]" || echo "Permission for script '/davsonfilerenamer/run.sh' [FAIL]"
echo "#Copying service"
sudo cp -v /home/${user}/davsonfilerenamer/service/davsonfilerenamer.service /etc/systemd/system
echo "#Copying timer"
sudo cp -v /home/${user}/davsonfilerenamer/timer/davsonfilerenamer.timer /etc/systemd/system
echo "#Installing service"
sudo systemctl deamon-reload
sudo systemctl enable davsonfilerenamer.service
sudo systemctl enable davsonfilerenamer.timer
sudo systemctl start davsonfilerenamer.service
sudo systemctl start davsonfilerenamer.timer

echo "#Prepare workingfolder"
function createFolders ()
{
	mkdir /home/${user}/davsonfilerenamer/BackupRenamerFolder
	mkdir /home/${user}/davsonfilerenamer/BackupRenamerFolder/images/ || echo -e "[DIR]: /BackupRenamerFolder/BackupRenamerFolder/images/ [FAIL]"
	mkdir /home/${user}/davsonfilerenamer/BackupRenamerFolder/video/ || echo -e "[DIR]: /BackupRenamerFolder/BackupRenamerFolder/video/ [FAIL]"
	mkdir /home/${user}/davsonfilerenamer/BackupRenamerFolder/temps/ || echo -e "[DIR]: /BackupRenamerFolder/BackupRenamerFolder/ [FAIL]"
	mkdir /home/${user}/davsonfilerenamer/BackupRenamerFolder/config/ || echo -e "[DIR]: /BackupRenamerFolder/BackupRenamerFolder/ [FAIL]"
}

function createFiles ()
{
	touch /home/${user}/davsonfilerenamer/BackupRenamerFolder/images/childs.jpeg || echo -e "[FILE]: /BackupRenamerFolder/images/childs.jpeg [FAIL]"
	touch /home/${user}/davsonfilerenamer/BackupRenamerFolder/images/cat.jpeg || echo -e "[FILE]: /BackupRenamerFolder/images/cat.jpeg [FAIL]"
	touch /home/${user}/davsonfilerenamer/BackupRenamerFolder/images/dog.jpeg || echo -e "[FILE]: /BackupRenamerFolder/images/images/dog.jpeg [FAIL]"
	touch /home/${user}/davsonfilerenamer/BackupRenamerFolder/images/factory.jpeg || echo -e "[FILE]: /BackupRenamerFolder/images/factory.jpeg [FAIL]"
	touch /home/${user}/davsonfilerenamer/BackupRenamerFolder/video/introduce.mp4 || echo -e "[FILE]: /BackupRenamerFolder/video/introduce.mp4 [FAIL]"
	touch /home/${user}/davsonfilerenamer/BackupRenamerFolder/video/video640x320.3gp || echo -e "[FILE]: /BackupRenamerFolder/video/video640x320.3gp [FAIL]"
	touch /home/${user}/davsonfilerenamer/BackupRenamerFolder/temps/var.temp || echo -e "[FILE]: /BackupRenamerFolder/temps/var.temp [FAIL]"
	touch /home/${user}/davsonfilerenamer/BackupRenamerFolder/config/init.conf || echo -e "[FILE]: /BackupRenamerFolder/config/init.conf [FAIL]"
}

function deleteAll ()
{
	rm -r /home/${user}/davsonfilerenamer/BackupRenamerFolder/ || echo -e "[DIR]: Deleted all files from /BackupRenamerFolder/* [FAIL]"
}

if [ -d "/home/${user}/davsonfilerenamer/BackupRenamerFolder/" ];
then
	deleteAll
	createFolders
	createFiles
			
else
	createFolders
	createFiles
fi
echo -e "Defaul folder has been restored!"
tree /home/${user}/davsonfilerenamer/BackupRenamerFolder/
