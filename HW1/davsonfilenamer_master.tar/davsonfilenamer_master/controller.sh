#!/bin/bash

#Read parameters that enter the script when they are entered
while getopts f:p: flag
do
    case "${flag}" in
        o) operation=${OPTARG};;
    esac
done

function enable () {
    systemctl enable davsonfilerenamer.service
    systemctl enable davsonfilerenamer.timer
}

function start () {
    systemctl start davsonfilerenamer.service
    systemctl start davsonfilerenamer.timer
}

function status () {
    systemctl status davsonfilerenamer.service
    systemctl status davsonfilerenamer.timer
}

function inspect () {
    journalctl -f -u davsonfilerenamer.service 
    journalctl -f -u davsonfilerenamer.timer
}

function stop () {
    systemctl stop davsonfilerenamer.service
    systemctl stop davsonfilerenamer.timer
}
function disabled () {
    systemctl disabled davsonfilerenamer.service
    systemctl disabled davsonfilerenamer.timer
}

function reload () {
    systemctl stop davsonfilerenamer.service
    systemctl stop davsonfilerenamer.timer
    systemctl start davsonfilerenamer.service
    systemctl start davsonfilerenamer.timer
}
function triggertimer () {
    systemctl start davsonfilerenamer.timer
}



if [ -z ${operation} ] ;
    then
    echo "Type: ./control.sh -o 'name'"
    echo "Nevybral jste co chcete se dealt: davsonfilerenamer.service/davsonfilerenamer.timer [start|status|reload|inspect|enable|disable|stop|triggertimer]"
    else
        case EXPRESSION in
            start)
                start
                ;;
            status)
                status
                ;;
            reload)
                reload
                ;;
            inspect)
                inspect
                ;;
            enable)
                enable
                ;;
            disable)
                disable
                ;;
            stop)
                disable
                ;;
            triggertimer)
                triggertimer
                ;;           
            *)
                exit 1
                ;;
        esac
fi
