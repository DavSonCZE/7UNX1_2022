#!/bin/bash
user=${whoami}

echo "Uninstaller for Homework#1 :"
echo "------------------------------------"
echo "Stopping service & timer:"
sudo systemctl disable davsonfilerenamer.service
sudo systemctl disable davsonfilerenamer.timer
sudo systemctl stop davsonfilerenamer.service
sudo systemctl stop davsonfilerenamer.timer
echo "Delete service & timer:"
sudo rm -v /etc/systemd/system/davsonfilerenamer.service
sudo rm -v /etc/systemd/system/davsonfilerenamer.timer
echo "Delete script folder"
rm /home/${user}/Downloads/davsonfilenamer_master.tar
rm -r /home/${user}/Downloads/davsonfilenamer_master
echo "Removing home folder for"
sudo rm -r /home/${user}/davsonfilerenamer
echo "Delete folder with scripts"
mkdir /home/${user}/Desktop/davsonrenamer_Control