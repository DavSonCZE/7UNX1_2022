#!/bin/bash
echo "Uninstaller for Homework#1 :"
echo "------------------------------------"
echo "Stopping service & timer:"
sudo systemctl disable davsonfilerenamer.service
sudo systemctl disable davsonfilerenamer.timer
sudo systemctl stop davsonfilerenamer.service
sudo systemctl stop davsonfilerenamer.timer
echo "Delete service & timer:"
sudo rm -v /etc/systemd/system/davsonfilerenamer.service
sudo rm -v /etc/systemd/system/davsonfilerenamer.timer
echo "Delete script folder"
rm /home/renamer/Downloads/davsonfilenamer_master.tar
rm -r /home/renamer/Downloads/davsonfilenamer_master
echo "Removing user"
sudo userdel renamer
echo "Removing home folder for"
sudo rm -r /home/renamer
echo "Delete folder with scripts"
mkdir /home/renamer/Desktop/davsonrenamer_Control