#!/bin/bash
#Creating default_folder

function createFolders ()
{
	mkdir /home/renamer/Desktop/BackupRenamerFolder
	mkdir /home/renamer/Desktop/BackupRenamerFolder/images/ || echo -e "[DIR]: $script_path/BackupRenamerFolder/images/ [FAIL]"
	mkdir /home/renamer/Desktop/BackupRenamerFolder/video/ || echo -e "[DIR]: $script_path/BackupRenamerFolder/video/ [FAIL]"
	mkdir /home/renamer/Desktop/BackupRenamerFolder/temps/ || echo -e "[DIR]: $script_path/BackupRenamerFolder/ [FAIL]"
	mkdir /home/renamer/Desktop/BackupRenamerFolder/config/ || echo -e "[DIR]: $script_path/BackupRenamerFolder/ [FAIL]"
}

function createFiles ()
{
	touch /home/renamer/Desktop/BackupRenamerFolder/images/childs.jpeg || echo -e "[FILE]: /BackupRenamerFolder/images/childs.jpeg [FAIL]"
	touch /home/renamer/Desktop/BackupRenamerFolder/images/cat.jpeg || echo -e "[FILE]: /BackupRenamerFolder/images/cat.jpeg [FAIL]"
	touch /home/renamer/Desktop/BackupRenamerFolder/images/dog.jpeg || echo -e "[FILE]: /BackupRenamerFolder/images/images/dog.jpeg [FAIL]"
	touch /home/renamer/Desktop/BackupRenamerFolder/images/factory.jpeg || echo -e "[FILE]: /BackupRenamerFolder/images/factory.jpeg [FAIL]"
	touch /home/renamer/Desktop/BackupRenamerFolder/video/introduce.mp4 || echo -e "[FILE]: /BackupRenamerFolder/video/introduce.mp4 [FAIL]"
	touch /home/renamer/Desktop/BackupRenamerFolder/video/video640x320.3gp || echo -e "[FILE]: /BackupRenamerFolder/video/video640x320.3gp [FAIL]"
	touch /home/renamer/Desktop/BackupRenamerFolder/temps/var.temp || echo -e "[FILE]: /BackupRenamerFolder/temps/var.temp [FAIL]"
	touch /home/renamer/Desktop/BackupRenamerFolder/config/init.conf || echo -e "[FILE]: /BackupRenamerFolder/config/init.conf [FAIL]"
}

function deleteAll ()
{
	rm -r /home/renamer/Desktop/BackupRenamerFolder/ || echo -e "[DIR]: Deleted all files from /BackupRenamerFolder/* [FAIL]"
}

#Main

if [ -d "/home/renamer/Desktop/BackupRenamerFolder/" ];
then
	deleteAll
	createFolders
	createFiles
			
else
	createFolders
	createFiles
fi
echo -e "Defaul folder has been restored!"
tree /home/renamer/Desktop/BackupRenamerFolder/




