#!/bin/bash
echo "Installer for Homework#1 :"
echo "------------------------------------"
echo "Installing prerequisites"
sudo apt-get install tree
echo "#Adding an account"
sudo useradd -m -U renamer
echo "#Set up password [default-password: code12569]"
sudo passwd renamer 
echo "#Copying file s to the home folder for user RENAMER: [DIR]davsonfilerenamer"
cp -r /home/renamer/Downloads/davsonfilenamer_master/davsonfilerenamer/ /home/renamer/davsonfilerenamer/
echo "#Setting permissions for files:"
chmod -R 770 /home/renamer/davsonfilerenamer & echo "[#] Permission for folders(Subfolders) '/davsonfilerenamer' [OK]" || echo "[#] Permission for folder 'davsonfilerenamer' [FAIL]"
chmod +x /home/renamer/davsonfilerenamer/autorun.sh & echo "[#] Permission for script '/davsonfilerenamer/autorun.sh' [OK]" || echo "Permission for script '/davsonfilerenamer/autorun.sh' [FAIL]"
chmod +x /home/renamer/davsonfilerenamer/run.sh & echo "[#] Permission for script '/davsonfilerenamer/run.sh' [OK]" || echo "Permission for script '/davsonfilerenamer/run.sh' [FAIL]"
echo "#Copying service"
sudo cp -v /home/renamer/davsonfilerenamer/service/davsonfilerenamer.service /etc/systemd/system
echo "#Copying timer"
sudo cp -v /home/renamer/davsonfilerenamer/timer/davsonfilerenamer.timer /etc/systemd/system
echo "#Installing service"
sudo systemctl deamon-reload
sudo systemctl enable davsonfilerenamer.service
sudo systemctl enable davsonfilerenamer.timer
sudo systemctl start davsonfilerenamer.service
sudo systemctl start davsonfilerenamer.timer